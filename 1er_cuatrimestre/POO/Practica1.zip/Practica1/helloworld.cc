//helloworld.cc
//Imprime "hello world"

#include <iostream>
main(){
int x;

std::cout<<"hola mundo\nhello world\n"<<"Introduce un valor de x: ";
std::cin>>x;
std::cout<<x<<"\n";
}
