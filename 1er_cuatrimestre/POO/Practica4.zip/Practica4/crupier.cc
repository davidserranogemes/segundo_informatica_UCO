#include "crupier.h"
namespace ruleta{

}
